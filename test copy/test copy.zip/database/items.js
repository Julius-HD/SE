// const { Integer } = require("mongodb");

module.exports = {
	item: {
		// index: { type: Integer, required: true },
		title: { type: String, required: true},
		question: { type: String, required: true },
		answer: {type: String, require:true}
	}
}; 